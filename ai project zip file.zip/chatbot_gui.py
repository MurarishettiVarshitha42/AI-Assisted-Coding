import csv
import tkinter as tk
from tkinter import scrolledtext

# -------- Load dataset ----------
crop_data = []
pest_data = []
tip_data = []

try:
    with open("data.csv", newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            if row['type'].strip().lower() == 'crop':
                crop_data.append(row)
            elif row['type'].strip().lower() == 'pest':
                pest_data.append(row)
            elif row['type'].strip().lower() == 'tip':
                tip_data.append(row)
except FileNotFoundError:
    print("Error: data.csv not found in the current folder.")
    exit()

# -------- Functions -----------------
def get_crop_info(crop_name):
    for row in crop_data:
        if row['name'].lower() == crop_name.lower():
            return f"🌾 Crop: {row['name']}\n Soil: {row['soil']}\n Season: {row['season']}\n Fertilizer: {row['fertilizer']}"
    return "Unknown crop. Options: " + ", ".join([c['name'] for c in crop_data])

def get_pest_info(pest_name):
    for row in pest_data:
        if row['name'].lower() == pest_name.lower():
            return f"🐛 Pest: {row['name']} (Crop: {row['crop_for_pest']})\n Solution: {row['solution']}"
    return "Unknown pest. Options: " + ", ".join([p['name'] for p in pest_data])

def get_general_tips():
    tips_list = [t['tip'] for t in tip_data if t['tip'].strip() != ""]
    return "\n".join([f"💡 {tip}" for tip in tips_list])

def get_response(user_input):
    global state
    user_input = user_input.strip().lower()

    if state == "main":
        if user_input in ["1", "crop", "crop info"]:
            state = "crop"
            return "Which crop? Options: " + ", ".join([c['name'] for c in crop_data])
        elif user_input in ["2", "pest", "pest info"]:
            state = "pest"
            return "Which pest? Options: " + ", ".join([p['name'] for p in pest_data])
        elif user_input in ["3", "general", "general tips"]:
            return get_general_tips()
        else:
            return "Please choose 1 (Crop), 2 (Pest), or 3 (General Tips)."

    elif state == "crop":
        response = get_crop_info(user_input)
        state = "main"
        return response

    elif state == "pest":
        response = get_pest_info(user_input)
        state = "main"
        return response

# -------- GUI ----------------------
def send_message():
    user_msg = entry.get()
    if user_msg.strip() == "":
        return

    chat_window.insert(tk.END, f"You: {user_msg}\n")
    entry.delete(0, tk.END)

    bot_reply = get_response(user_msg)
    chat_window.insert(tk.END, f"Bot: {bot_reply}\n\n")
    chat_window.see(tk.END)

# -------- Tkinter Window -------------
state = "main"
root = tk.Tk()
root.title("🌾 Farmer Support Chatbot")
root.geometry("500x600")

chat_window = scrolledtext.ScrolledText(root, wrap=tk.WORD, font=("Arial", 12))
chat_window.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

entry = tk.Entry(root, font=("Arial", 14))
entry.pack(padx=10, pady=5, fill=tk.X)

send_btn = tk.Button(root, text="Send", font=("Arial", 12), command=send_message)
send_btn.pack(pady=5)

chat_window.insert(tk.END, "Bot: Hello! What do you want to know today?\n1️⃣ Crop info\n2️⃣ Pest info\n3️⃣ General tips\n\n")

root.mainloop()


